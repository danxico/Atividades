package br.unip.sicc.view;

import br.unip.sicc.dao.DadosException;
import static br.unip.sicc.view.Menu.Opcao.*;
import static br.unip.sicc.view.Menu.*;

public class ControleDeAtividades {

    public static void main(String[] args) {
        System.out.println("### CONTROLE DE ATIVIDADES ###");
        Opcao opcaoSelecionada = SAIR;
        do {
            Menu.exibeOpcoes();
            opcaoSelecionada = Menu.leOpcao();
            try {
                switch (opcaoSelecionada) {
                    case INCLUIR:
                        incluir();
                        break;
                    case ATUALIZAR:
                        atualizar();
                        break;
                    case EXCLUIR:
                        excluir();
                        break;
                    case GET_POR_ID:
                        getPorId();
                        break;
                    case GET_POR_TIPO:
                        getPorTipo();
                        break;
                    case GET_TODAS:
                        getTodas();
                        break;
                }
            } catch (DadosException ex) {
                System.out.println("... ERRO AO EXECUTAR A OPERACAO");
            }
        } while (!opcaoSelecionada.equals(Menu.Opcao.SAIR));

    }

}
