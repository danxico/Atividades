package br.unip.sicc.view;

import br.unip.sicc.model.GerenciadorDeAtividades;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class TelaControleAtividades extends JFrame implements WindowListener{

    private PainelCadastroAtividade painelCadastroAtividade;
    private PainelBuscaAtividades painelBuscaAtividades;
    
    private GerenciadorDeAtividades gerenciador;

    //implementacao do padrao Singleton
    private static TelaControleAtividades instance;
    
    private TelaControleAtividades() {
        
        gerenciador = GerenciadorDeAtividades.getInstance();

        this.setTitle("Controle de Atividades");
        this.setSize(800, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.addWindowListener(this);

        painelCadastroAtividade = PainelCadastroAtividade.getInstance();
        painelBuscaAtividades = PainelBuscaAtividades.getInstance();

        this.add(painelCadastroAtividade, BorderLayout.WEST);
        this.add(painelBuscaAtividades, BorderLayout.CENTER);
        this.setJMenuBar(montaMenu());

        this.setVisible(true);

    }

    public static TelaControleAtividades getInstance() {
        if (instance == null) {
            instance = new TelaControleAtividades();
        }
        return instance;
    }

    
    //implementacao do padrao Singleton
   
    private JMenuBar montaMenu() {
        JMenuBar barraMenu = new JMenuBar();
        JMenu menuCadastro = new JMenu("Cadastro");
        menuCadastro.setMnemonic(KeyEvent.VK_T);
        JMenu menuAjuda = new JMenu("Ajuda");
        menuAjuda.setMnemonic(KeyEvent.VK_A);
        JMenuItem itemNovo = new JMenuItem("Novo");
        itemNovo.setMnemonic(KeyEvent.VK_N);
        itemNovo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                painelCadastroAtividade.setAtividade(gerenciador.getNovaAtividade());
            }
        });
        JMenuItem itemSobre = new JMenuItem("Sobre");
        itemSobre.setMnemonic(KeyEvent.VK_S);
        itemSobre.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String mensagemSobre = "Software desenvolvido na disciplona ALPOO";
                JOptionPane.showMessageDialog(null, mensagemSobre,
                        "Sobre", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        menuCadastro.add(itemNovo);
        menuAjuda.add(itemSobre);
        barraMenu.add(menuCadastro);
        barraMenu.add(menuAjuda);
        return barraMenu;
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TelaControleAtividades tela = TelaControleAtividades.getInstance();
            }
        });
    }

    @Override
    public void windowOpened(WindowEvent e) {
    }

    @Override
    public void windowClosing(WindowEvent e) {
    }

    @Override
    public void windowClosed(WindowEvent e) {
    }

    @Override
    public void windowIconified(WindowEvent e){
        System.out.println("Minimizou");
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }

}
