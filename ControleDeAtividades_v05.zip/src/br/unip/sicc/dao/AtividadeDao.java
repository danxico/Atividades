package br.unip.sicc.dao;

import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.TipoAtividade;
import java.util.List;

public interface AtividadeDao {

    public void incluir(AtividadeComplementar atividade) throws DadosException;

    public void atualizar(AtividadeComplementar atividade)  throws DadosException;

    public void excluir(AtividadeComplementar atividade)  throws DadosException;
    
    public AtividadeComplementar getPorId(Integer id) throws DadosException;

    public List<AtividadeComplementar> getPorTipo(TipoAtividade tipo) throws DadosException;

    public List<AtividadeComplementar> getTodas() throws DadosException;
    
}
