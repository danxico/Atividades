package br.unip.sicc.dao;

import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.Situacao;
import br.unip.sicc.model.TipoAtividade;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class AtividadeJdbc implements AtividadeDao {

    private static final String SQL_INSERT
            = "INSERT INTO TB_ATIVIDADES (TITULO, TIPO, DATA_REAL, QTDE_HORAS, SITUACAO) "
            + "VALUES (?, ?, ?, ?, ?);";
    // 1  2  3  4  5

    @Override
    public void incluir(AtividadeComplementar atividade) throws DadosException {
        Connection connection = GerenciadorConexao.getConnection();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, atividade.getTitulo());
            statement.setString(2, atividade.getTipo().name());
            java.sql.Date dataSql
                    = new java.sql.Date(atividade.getDataRealizacao().getTime());
            statement.setDate(3, dataSql);
            statement.setInt(4, atividade.getQtdeHoras());
            statement.setString(5, atividade.getSituacao().name());
            int qtdeRegistros = statement.executeUpdate();
        } catch (SQLException ex) {
            throw new DadosException(
                    "Não foi possivel incluir", ex);
        } finally {
            GerenciadorConexao.fechar(connection, statement);
        }
    }
    private static final String SQL_DELETE
            = "DELETE FROM TB_ATIVIDADES WHERE ID = ?;";

    @Override
    public void excluir(AtividadeComplementar atividade) throws DadosException {
        Connection connection = GerenciadorConexao.getConnection();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(SQL_DELETE);
            statement.setInt(1, atividade.getId());
            int qtdeRegistros = statement.executeUpdate();
        } catch (SQLException ex) {
            throw new DadosException(
                    "Não foi possivel excluir", ex);
        } finally {
            GerenciadorConexao.fechar(connection, statement);
        }
    }

    private static final String SQL_UPDATE
            = "UPDATE TB_ATIVIDADES SET TITULO = ?, TIPO = ? , DATA_REAL = ? , QTDE_HORAS = ? , SITUACAO= ?  WHERE ID = ?;";
    //1          2            3           4            5                  6

    @Override
    public void atualizar(AtividadeComplementar atividade) throws DadosException {
        Connection connection = GerenciadorConexao.getConnection();
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(SQL_UPDATE);
            statement.setString(1, atividade.getTitulo());
            statement.setString(2, atividade.getTipo().name());
            java.sql.Date dataSql
                    = new java.sql.Date(atividade.getDataRealizacao().getTime());
            statement.setDate(3, dataSql);
            statement.setInt(4, atividade.getQtdeHoras());
            statement.setString(5, atividade.getSituacao().name());
            statement.setInt(6, atividade.getId());
            int qtdeRegistros = statement.executeUpdate();
        } catch (SQLException ex) {
            throw new DadosException(
                    "Não foi possivel atualizar", ex);
        } finally {
            GerenciadorConexao.fechar(connection, statement);
        }
    }
    // implementacao do padrao Singleton
    private static AtividadeJdbc instance;

    public static AtividadeJdbc getInstance() {
        if (instance == null) {
            instance = new AtividadeJdbc();
        }
        return instance;
    }

    private AtividadeJdbc() {
    }
    //

    private static final String SQL_SELECT_POR_ID
            = "SELECT ID, TITULO, TIPO, DATA_REAL, QTDE_HORAS, SITUACAO "
            + " FROM TB_ATIVIDADES WHERE ID=?;";

    @Override
    public AtividadeComplementar getPorId(Integer id) throws DadosException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static final String SQL_SELECT_POR_TIPO
            = "SELECT ID, TITULO, TIPO, DATA_REAL, QTDE_HORAS, SITUACAO "
            + " FROM TB_ATIVIDADES WHERE TIPO = ?;";

    @Override
    public List<AtividadeComplementar> getPorTipo(TipoAtividade tipo) throws DadosException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static final String SQL_SELECT_ALL
            = "SELECT ID, TITULO, TIPO, DATA_REAL, QTDE_HORAS, SITUACAO "
            + " FROM TB_ATIVIDADES;";

    @Override
    public List<AtividadeComplementar> getTodas() throws DadosException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
