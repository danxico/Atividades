package br.unip.sicc.model;

public enum Situacao {
    ENTREGUE,//0
    APROVADA,//1
    REPROVADA;//2
}
