package br.unip.sicc.view;

import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.GerenciadorDeAtividades;
import br.unip.sicc.model.Situacao;
import br.unip.sicc.model.TipoAtividade;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

public class PainelCadastroAtividade extends JPanel {

    private JLabel lblId;
    private JTextField txtId;
    private JLabel lblTitulo;
    private JTextField txtTitulo;
    private JLabel lblTipo;
    private JComboBox cboTipo;
    private JLabel lblData;
    private JFormattedTextField txtData;
    private JLabel lblQtde;
    private JSpinner spiQtde;
    private JLabel lblSituacao;
    private JComboBox cboSituacao;
    private JButton btnSalvar;
    private JButton btnCancelar;

    private GerenciadorDeAtividades gerenciador;

    private AtividadeComplementar atividade;

    //implementação do Singleton
    private static PainelCadastroAtividade instance;

    private PainelCadastroAtividade() {

        gerenciador = GerenciadorDeAtividades.getInstance();
        BorderLayout layout = new BorderLayout();
        this.setLayout(layout);
        JPanel painelCadastro = montaPainelCadastro();
        JPanel painelBotoes = montaPainelBotoes();
        this.add(painelCadastro, BorderLayout.CENTER);
        this.add(painelBotoes, BorderLayout.SOUTH);
    }

    public static PainelCadastroAtividade getInstance() {
        if (instance == null) {
            instance = new PainelCadastroAtividade();
        }
        return instance;
    }

    //implementação do Singleton
    private JPanel montaPainelCadastro() {
        JPanel painelCadastro = new JPanel();
        GridLayout layout = new GridLayout(6, 2);
        painelCadastro.setLayout(layout);

        lblId = new JLabel("Id:");
        txtId = new JTextField();
        txtId.setEditable(false);
        txtId.setColumns(10);
        lblTitulo = new JLabel("Titulo:");
        txtTitulo = new JTextField();
        lblTipo = new JLabel("Tipo:");
        TipoAtividade[] tipos = TipoAtividade.values();
        cboTipo = new JComboBox(tipos);
        lblData = new JLabel("Data:");
        DateFormat formatadorData = DateFormat.getDateInstance(DateFormat.SHORT);
        txtData = new JFormattedTextField(formatadorData);
        lblQtde = new JLabel("Qtde:");
        SpinnerNumberModel spinnerNumberModel = new SpinnerNumberModel(0, 0, 100, 5);
        spiQtde = new JSpinner(spinnerNumberModel);
        lblSituacao = new JLabel("Situação:");
        Situacao[] situacoes = Situacao.values();
        cboSituacao = new JComboBox(situacoes);

        painelCadastro.add(lblId);
        painelCadastro.add(txtId);
        painelCadastro.add(lblTitulo);
        painelCadastro.add(txtTitulo);
        painelCadastro.add(lblTipo);
        painelCadastro.add(cboTipo);
        painelCadastro.add(lblData);
        painelCadastro.add(txtData);
        painelCadastro.add(lblQtde);
        painelCadastro.add(spiQtde);
        painelCadastro.add(lblSituacao);
        painelCadastro.add(cboSituacao);
        return painelCadastro;
    }

    private JPanel montaPainelBotoes() {
        JPanel painelBotoes = new JPanel();
        FlowLayout layout = new FlowLayout(FlowLayout.RIGHT);
        painelBotoes.setLayout(layout);
        btnSalvar = new JButton("Salvar");
        btnSalvar.setMnemonic(KeyEvent.VK_S);
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setMnemonic(KeyEvent.VK_C);
        painelBotoes.add(btnCancelar);
        painelBotoes.add(btnSalvar);
        return painelBotoes;
    }

    void setAtividade(AtividadeComplementar atividade) {
        this.atividade = atividade;
        txtId.setText(atividade.getId().toString());
        txtTitulo.setText(atividade.getTitulo());
        cboTipo.setSelectedItem(atividade.getTipo());
        txtData.setValue(atividade.getDataRealizacao());
        spiQtde.setValue(atividade.getQtdeHoras());
        cboSituacao.setSelectedItem(atividade.getSituacao());
    }

    private AtividadeComplementar getAtividadeAlterada() {
        AtividadeComplementar atividadeAlterada = new AtividadeComplementar();
        atividadeAlterada.setId(Integer.parseInt(txtId.getText()));
        atividadeAlterada.setTitulo(txtTitulo.getText());
        TipoAtividade tipo = (TipoAtividade) cboTipo.getSelectedItem();
        atividadeAlterada.setTipo(tipo);
        Date data = (Date) txtData.getValue();
        atividadeAlterada.setDataRealizacao(data);
        Integer qtde = (Integer) spiQtde.getValue();
        atividadeAlterada.setQtdeHoras(qtde);
        Situacao situacao = (Situacao) cboSituacao.getSelectedItem();
        atividadeAlterada.setSituacao(situacao);
        return atividadeAlterada;
    }

}