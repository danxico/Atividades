package br.unip.sicc.model; 


import br.unip.sicc.dao.AtividadeList;
import br.unip.sicc.dao.DadosException;
import java.util.Date;
import java.util.List;

public class GerenciadorDeAtividades {

    //implementacao do Singleton
    private static GerenciadorDeAtividades instance;

    private GerenciadorDeAtividades() {
    }

    public static GerenciadorDeAtividades getInstance() {
        if (instance == null) {
            instance = new GerenciadorDeAtividades();
        }
        return instance;
    }
    //implementacao do Singleton
    
    private AtividadeList dao = new AtividadeList();

    public AtividadeComplementar getNovaAtividade(){
        AtividadeComplementar atividade = new AtividadeComplementar();
        atividade.setId(new Integer(0));
        atividade.setTipo(TipoAtividade.CULTURAL);
        atividade.setDataRealizacao(new Date());
        atividade.setQtdeHoras(0);
        atividade.setSituacao(Situacao.ENTREGUE);
        return atividade;
    }  
    public void salvar(AtividadeComplementar atividade) throws DadosException {
        boolean ehNova = atividade != null && atividade.getId() != null
                && !(atividade.getId() > 0);
        if (ehNova) {
            dao.incluir(atividade);
        } else {
            dao.atualizar(atividade);
        }
    }

    public void excluir(AtividadeComplementar atividade) throws DadosException {
        dao.excluir(atividade);
    }

    public AtividadeComplementar getPorId(Integer id) throws DadosException {
        return dao.getPorId(id);
    }

    public List<AtividadeComplementar> getPorTipo(TipoAtividade tipo) throws DadosException {
        if (tipo != null) {
            return dao.getPorTipo(tipo);
        } else {
            return dao.getTodas();
        }
    }

    public List<AtividadeComplementar> getTodas() throws DadosException {
        return dao.getTodas();
    }

}
