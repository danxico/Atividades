package br.unip.sicc.model;

public enum TipoAtividade {
    CURSO,
    CULTURAL,
    EVENTO,
    MONITORIA,
    INICIACAO_CIENTIFICA;
}
