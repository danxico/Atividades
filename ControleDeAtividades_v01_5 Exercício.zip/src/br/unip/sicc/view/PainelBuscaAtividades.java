package br.unip.sicc.view;

import br.unip.sicc.dao.DadosException;
import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.GerenciadorDeAtividades;
import br.unip.sicc.model.TipoAtividade;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.TableModel;

public class PainelBuscaAtividades extends JPanel {

    private JLabel lblFiltro;
    private JComboBox cboFiltro;
    private JButton btnFiltro;
    private JTable tabelaAtividades;
    private JButton btnSelecionar;
    private JButton btnExcluir;

    private GerenciadorDeAtividades gerenciador;

    //implementação do Singleton
    private static PainelBuscaAtividades instance;

    private PainelBuscaAtividades() {
        this.gerenciador = GerenciadorDeAtividades.getInstance();

        this.setLayout(new BorderLayout());
        JPanel painelFiltro = montaPainelFiltro();
        JScrollPane painelTabela = montaPainelTabela();
        JPanel painelBotoes = montaPainelBotoes();

        this.add(painelFiltro, BorderLayout.NORTH);
        this.add(painelTabela, BorderLayout.CENTER);
        this.add(painelBotoes, BorderLayout.SOUTH);

    }

    public static PainelBuscaAtividades getInstance() {
        if (instance == null) {
            instance = new PainelBuscaAtividades();
        }
        return instance;
    }
    //implementação do Singleton

    private JPanel montaPainelFiltro() {
        JPanel painelFiltro = new JPanel();
        lblFiltro = new JLabel("Tipo");
        TipoAtividade[] tipos = TipoAtividade.values();
        cboFiltro = new JComboBox(tipos);
        cboFiltro.insertItemAt("TODOS", 0);
        cboFiltro.setSelectedIndex(0);
        btnFiltro = new JButton("Buscar");
        btnFiltro.setMnemonic(KeyEvent.VK_B);
        
        painelFiltro.add(lblFiltro);
        painelFiltro.add(cboFiltro);
        painelFiltro.add(btnFiltro);
        return painelFiltro;
    }

    private JPanel montaPainelBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnSelecionar = new JButton("Selecionar");
        btnSelecionar.setMnemonic(KeyEvent.VK_S);
        btnExcluir = new JButton("Excluir");
        btnExcluir.setMnemonic(KeyEvent.VK_X);

        painel.add(btnSelecionar);
        painel.add(btnExcluir);
        return painel;
    }

    private JScrollPane montaPainelTabela() {
        TableModel model = null;
        try {
            List<AtividadeComplementar> atividades = gerenciador.getTodas();
            //Inicialize o model com um objeto do tipo AtividadeTableModel
            model = null;
        } catch (DadosException ex) {
            ex.printStackTrace();
        }
        tabelaAtividades = new JTable(model);
        tabelaAtividades.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(tabelaAtividades);
        return scroll;
    }

}
