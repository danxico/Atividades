package br.unip.sicc.view;

import br.unip.sicc.model.AtividadeComplementar;
import java.util.List;

public class AtividadeTableModel{
    
    private List<AtividadeComplementar> atividades;

    public AtividadeTableModel(List<AtividadeComplementar> atividades) {
        this.atividades = atividades;
    }
    
    AtividadeComplementar getAtividade(int linha){
        return atividades.get(linha);
    }

    void setAtividades(List<AtividadeComplementar> atividades) {
        this.atividades = atividades;
    }
    
}
