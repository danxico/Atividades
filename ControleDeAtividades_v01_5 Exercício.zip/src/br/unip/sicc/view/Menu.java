package br.unip.sicc.view;

import br.unip.sicc.dao.DadosException;
import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.GerenciadorDeAtividades;
import br.unip.sicc.model.TipoAtividade;
import java.util.List;
import java.util.Scanner;

public class Menu {

    private static final GerenciadorDeAtividades gerenciador = 
            GerenciadorDeAtividades.getInstance();
    public static final Scanner teclado = new Scanner(System.in);

    static void exibeOpcoes() {
        System.out.println("OPÇÕES");
        for (Opcao opcao : Opcao.values()) {
            System.out.println("\t" + opcao.getDescricao());
        }
    }

    static void exibeTipos() {
        System.out.println("TIPOS");
        for (TipoAtividade tipo : TipoAtividade.values()) {
            System.out.println("\t" + tipo.ordinal() + " " + tipo);
        }
    }

    static Opcao leOpcao() {
        System.out.println("ESCOLHA A OPCAO DESEJADA");
        String opcaoDigitada = teclado.next();
        Opcao opcaoSelecionada = verificaOpcaoDigitada(opcaoDigitada);
        return opcaoSelecionada;
    }

    private static Opcao verificaOpcaoDigitada(String opcaoDigitada) {
        Opcao opcao = null;
        try {
            int opcaoInt = Integer.parseInt(opcaoDigitada);
            opcao = Opcao.values()[opcaoInt];
        } catch (Exception ex) {
            return Opcao.SAIR;
        }
        return opcao;
    }

    static String leTitulo() {
        System.out.println("Informe o Titulo da Atividade Complementar");
        String tituloDigitado = teclado.nextLine();
        String tituloSelecionado = verificaTituloDigitado(tituloDigitado);
        return tituloSelecionado;
    }

    private static String verificaTituloDigitado(String tituloDigitado) {
        if (tituloDigitado == null || tituloDigitado.isEmpty()) {
            return "Titulo não informado";
        }
        return tituloDigitado;
    }

    static TipoAtividade leTipo() {
        System.out.println("Informe o Tipo da Atividade Complementar");
        exibeTipos();
        String tipoDigitado = teclado.next();
        TipoAtividade tipoSelecionado = verificaTipoDigitado(tipoDigitado);
        return tipoSelecionado;
    }

    private static TipoAtividade verificaTipoDigitado(String tipoDigitado) {
        TipoAtividade tipo = null;
        try {
            int tipoInt = Integer.parseInt(tipoDigitado);
            tipo = TipoAtividade.values()[tipoInt];
        } catch (Exception ex) {
            return TipoAtividade.EVENTO;//tipo padrao
        }
        return tipo;
    }

    static int leQtdeHoras() {
        System.out.println("Informe a Quantidade de Horas da Atividade Complementar");
        return leInt();
    }

    private static int leInt() {
        String intDigitado = teclado.next();
        int intSelecionado = verificaIntDigitado(intDigitado);
        return intSelecionado;
    }

    private static int verificaIntDigitado(String intDigitado) {
        int intSelecionado = 0;
        try {
            intSelecionado = Integer.parseInt(intDigitado);
        } catch (Exception ex) {
            return intSelecionado;
        }
        return intSelecionado;
    }

    static int leId() {
        System.out.println("Informe o ID da Atividade Complementar");
        return leInt();
    }

    static void incluir() throws DadosException {
        System.out.println("INCLUIR ...");
        String titulo = leTitulo();
        TipoAtividade tipo = leTipo();
        int qtdeHoras = leQtdeHoras();
        AtividadeComplementar novaAtividade = gerenciador.getNovaAtividade();
        novaAtividade.setTitulo(titulo);
        novaAtividade.setTipo(tipo);
        novaAtividade.setQtdeHoras(qtdeHoras);
        gerenciador.salvar(novaAtividade);
    }

    static void excluir() throws DadosException {
        System.out.println("EXCLUIR ...");
        int id = leId();
        AtividadeComplementar atividadeComplementar = gerenciador.getPorId(id);
        if (atividadeComplementar == null) {
            System.out.println("ID NAO LOCALIZADO");
        } else {
            gerenciador.excluir(atividadeComplementar);
        }
    }

    static void atualizar() {
        System.out.println("ATUALIZAR ... NÃO IMPLEMENTADO");
    }

    static void getPorId() throws DadosException {
        System.out.println("SELECIONAR PELO ID ...");
        int id = leId();
        AtividadeComplementar atividade = gerenciador.getPorId(id);
        System.out.println(atividade);
    }

    static void getPorTipo() throws DadosException {
        System.out.println("SELECIONAR PELO TIPO ...");
        TipoAtividade tipo = leTipo();
        List<AtividadeComplementar> atividades = gerenciador.getPorTipo(tipo);
        for (AtividadeComplementar atividade : atividades) {
            System.out.println(atividade);
        }
    }

    static void getTodas() throws DadosException {
        System.out.println("SELECIONAR TODAS ...");
        List<AtividadeComplementar> atividades = gerenciador.getTodas();
        for (AtividadeComplementar atividade : atividades) {
            System.out.println(atividade);
        }
    }

    enum Opcao {
        SAIR("0 SAIR"),
        INCLUIR("1 INCLUIR"),
        ATUALIZAR("2 ATUALIZAR"),
        EXCLUIR("3 EXCLUIR"),
        GET_POR_ID("4 SELECIONAR PELO ID"),
        GET_POR_TIPO("5 SELECIONAR PELO TIPO"),
        GET_TODAS("6 SELECIONAR TODAS");

        private Opcao(String descricao) {
            this.descricao = descricao;
        }

        private String descricao;

        public String getDescricao() {
            return descricao;
        }

    }

}
