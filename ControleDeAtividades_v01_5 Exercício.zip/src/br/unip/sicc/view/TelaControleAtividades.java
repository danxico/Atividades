package br.unip.sicc.view;

import br.unip.sicc.model.GerenciadorDeAtividades;
import java.awt.BorderLayout;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class TelaControleAtividades extends JFrame{

    private PainelCadastroAtividade painelCadastroAtividade;
    private PainelBuscaAtividades painelBuscaAtividades;
    
    private GerenciadorDeAtividades gerenciador;

    //implementacao do padrao Singleton
    private static TelaControleAtividades instance;
    
    private TelaControleAtividades() {
        
        gerenciador = GerenciadorDeAtividades.getInstance();

        this.setTitle("Controle de Atividades");
        this.setSize(800, 300);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        painelCadastroAtividade = PainelCadastroAtividade.getInstance();
        painelBuscaAtividades = PainelBuscaAtividades.getInstance();

        this.add(painelCadastroAtividade, BorderLayout.WEST);
        this.add(painelBuscaAtividades, BorderLayout.CENTER);
        this.setJMenuBar(montaMenu());

        this.setVisible(true);

    }

    public static TelaControleAtividades getInstance() {
        if (instance == null) {
            instance = new TelaControleAtividades();
        }
        return instance;
    }

    
    //implementacao do padrao Singleton
   
    private JMenuBar montaMenu() {
        JMenuBar barraMenu = null;
        JMenu menuCadastro = new JMenu("Cadastro");
        JMenu menuAjuda = new JMenu("Ajuda");
        JMenuItem itemNovo = new JMenuItem("Novo");
        JMenuItem itemSobre = new JMenuItem("Sobre");
        menuCadastro.add(itemNovo);
        //Adicione o item Sobre no menu Ajuda
        return barraMenu;
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TelaControleAtividades tela = TelaControleAtividades.getInstance();
            }
        });
    }

}
