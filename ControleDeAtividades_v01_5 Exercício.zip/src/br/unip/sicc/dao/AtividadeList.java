package br.unip.sicc.dao;

import br.unip.sicc.model.AtividadeComplementar;
import br.unip.sicc.model.Situacao;
import br.unip.sicc.model.TipoAtividade;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AtividadeList {

    private List<AtividadeComplementar> atividades;
    private static int contador = 1;

    public AtividadeList() {
        atividades = new ArrayList<>();
        atividades.add(new AtividadeComplementar(contador++, "Piratas do Silício", TipoAtividade.CULTURAL, new Date(), 5, Situacao.ENTREGUE));
        atividades.add(new AtividadeComplementar(contador++, "IA na prática", TipoAtividade.CURSO, new Date(), 10, Situacao.ENTREGUE));
        atividades.add(new AtividadeComplementar(contador++, "Rodin no vão do Masp", TipoAtividade.CULTURAL, new Date(), 5, Situacao.ENTREGUE));
        atividades.add(new AtividadeComplementar(contador++, "IoT for Dummies", TipoAtividade.EVENTO, new Date(), 10, Situacao.ENTREGUE));
        atividades.add(new AtividadeComplementar(contador++, "Monitoria LPOO", TipoAtividade.MONITORIA, new Date(), 20, Situacao.ENTREGUE));
    }

    public void incluir(AtividadeComplementar atividade) throws DadosException {
        if (atividade != null) {
            atividade.setId(contador++);
            atividades.add(atividade);
        } else {
            throw new DadosException("Atividade nula");
        }
    }

    public void atualizar(AtividadeComplementar atividade) throws DadosException {
        if (atividade != null) {
            for (AtividadeComplementar atividadeAtual : atividades) {
                if (atividadeAtual.getId() == atividade.getId()) {
                    int indice = atividades.indexOf(atividadeAtual);
                    atividades.set(indice, atividade);
                    break;
                }
            }
        } else {
            throw new DadosException("Atividade nula");
        }
    }

    public void excluir(AtividadeComplementar atividade) throws DadosException {
        if (atividade != null) {
            atividades.remove(atividade);
        } else {
            throw new DadosException("Atividade nula");
        }
    }

    public AtividadeComplementar getPorId(Integer id) throws DadosException {
        AtividadeComplementar atividade = null;
        for (AtividadeComplementar atividadeAtual : atividades) {
            if (atividadeAtual.getId() == id) {
                atividade = atividadeAtual;
                break;
            }
        }
        return atividade;
    }

    public List<AtividadeComplementar> getPorTipo(TipoAtividade tipo) throws DadosException {
        List<AtividadeComplementar> atividadesFiltradas = new ArrayList<>();
        for (AtividadeComplementar atividadeAtual : atividades) {
            if (atividadeAtual.getTipo() == tipo) {
                atividadesFiltradas.add(atividadeAtual);
            }
        }
        return atividadesFiltradas;
    }

    public List<AtividadeComplementar> getTodas() throws DadosException {
        return atividades;
    }

}
